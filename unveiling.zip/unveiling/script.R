

scores<-read.table("scores.txt", h=T)
numscores<-length(unique(scores[,4]))
answers<-aggregate(rep(1,nrow(scores))~scores[,4], FUN="sum")
#Number of users scoring all 9 butterly pictures
length(which(answers[,2]==9))


pairs<-read.table("pairs.txt", h=T)
numpairs<-length(unique(pairs[,3]))
answersp<-aggregate(rep(1,nrow(pairs))~pairs[,3], FUN="sum")
#Number of users scoring all the 10 pairs of pictures
length(which(answersp[,2]==10))


emo<-read.table("emotions.txt", h=T)
numemo<-length(unique(emo[,5]))
answerse<-aggregate(rep(1,nrow(emo))~emo[,5], FUN="sum")
#Number of users scoring all the 10 pairs of pictures
length(which(answerse[,2]==5))


quest<-read.table("questions.txt", h=T)
numquest<-length(unique(quest[,4]))
answersq<-aggregate(rep(1,nrow(quest))~quest[,4], FUN="sum")
#Number of users answering all the 18 questions
length(which(answersq[,2]==18))

library(glmmTMB)
library(emmeans)
scoreflowers<-read.table("vote_flowers.txt", h=T)
glmm1<-glmmTMB(vote~flower+(1|species), data=votifiore)
summary(glmm1)
emmeans(glmm, "flower")